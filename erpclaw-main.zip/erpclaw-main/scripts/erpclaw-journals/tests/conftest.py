"""Pytest fixtures for ERPClaw Journals CWIP-hook unit tests (AVA-43)."""
import os
import sys

_TESTS_DIR = os.path.dirname(os.path.abspath(__file__))
if _TESTS_DIR not in sys.path:
    sys.path.insert(0, _TESTS_DIR)

import pytest
from journals_helpers import init_all_tables, get_conn, build_journals_env


@pytest.fixture
def db_path(tmp_path):
    path = str(tmp_path / "test.sqlite")
    init_all_tables(path)
    os.environ["ERPCLAW_DB_PATH"] = path
    yield path
    os.environ.pop("ERPCLAW_DB_PATH", None)


@pytest.fixture
def conn(db_path):
    connection = get_conn(db_path)
    yield connection
    connection.close()


@pytest.fixture
def env(conn):
    return build_journals_env(conn)
